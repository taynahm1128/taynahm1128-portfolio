import { useState, useEffect, useCallback, useMemo } from 'react';
import { MapPin, Calendar, Clock, X, Sparkles, ArrowRight, Plus, Trash2, Tag, AlertCircle, LogOut, UserCircle } from 'lucide-react';
import { AGE_GROUPS, getAgeGroupInfo, formatDate, formatLongDate } from './lib/ageGroups';
import { fetchEventsByAge, fetchEventById, createEvent, deleteEvent, parsePrice } from './lib/events';
import { getStoredProfileId, clearStoredProfileId, fetchProfile } from './lib/profiles';
import type { AgeGroup, Event, Profile } from './lib/supabase';
import SignUpView from './components/SignUpView';
import ProfileView from './components/ProfileView';
import PriceRangeSlider from './components/PriceRangeSlider';
import CreatorsView from './components/CreatorsView';

type View = 'home' | 'events' | 'profile' | 'creators';

export default function App() {
  const [view, setView] = useState<View>('home');
  const [selectedAge, setSelectedAge] = useState<AgeGroup | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [maxPrice, setMaxPrice] = useState(50);

  const [profile, setProfile] = useState<Profile | null>(null);
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    const storedId = getStoredProfileId();
    if (!storedId) {
      setAuthReady(true);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const found = await fetchProfile(storedId);
        if (!cancelled) setProfile(found);
      } catch {
        // stale id — treat as not signed in
      } finally {
        if (!cancelled) setAuthReady(true);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const handleSignUpComplete = (p: Profile) => {
    setProfile(p);
  };

  const loadEvents = useCallback(async (age: AgeGroup) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchEventsByAge(age);
      setEvents(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load events');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (view === 'events' && selectedAge) {
      loadEvents(selectedAge);
    }
  }, [view, selectedAge, loadEvents]);

  const handleSignOut = () => {
    clearStoredProfileId();
    setProfile(null);
    setView('home');
    setSelectedAge(null);
    setEvents([]);
    setError(null);
    setMaxPrice(50);
  };

  const filteredEvents = useMemo(
    () => events.filter((e) => parsePrice(e.price) <= maxPrice),
    [events, maxPrice]
  );

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return <SignUpView onComplete={handleSignUpComplete} />;
  }

  const handleSelectAge = (age: AgeGroup) => {
    setSelectedAge(age);
    setView('events');
  };

  const handleBackHome = () => {
    setView('home');
    setSelectedAge(null);
    setEvents([]);
    setError(null);
  };

  const handleEventClick = async (event: Event) => {
    setShowDetail(true);
    setDetailLoading(true);
    setSelectedEvent(event);
    try {
      const fresh = await fetchEventById(event.id);
      if (fresh) setSelectedEvent(fresh);
    } catch {
      // keep the already-loaded event data
    } finally {
      setDetailLoading(false);
    }
  };

  const handleEventCreated = () => {
    setShowCreate(false);
    if (selectedAge) loadEvents(selectedAge);
  };

  const handleEventDeleted = async (id: string) => {
    try {
      await deleteEvent(id);
      setShowDetail(false);
      setSelectedEvent(null);
      if (selectedAge) loadEvents(selectedAge);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete event');
    }
  };

  if (view === 'home') {
    return <HomeView onSelectAge={handleSelectAge} profile={profile} onSignOut={handleSignOut} onOpenProfile={() => setView('profile')} onOpenCreators={() => setView('creators')} />;
  }

  if (view === 'creators') {
    return <CreatorsView onBack={() => setView('home')} />;
  }

  if (view === 'profile') {
    return (
      <ProfileView
        profile={profile}
        onBack={() => setView('home')}
        onProfileChange={(p) => setProfile(p)}
        onAddAccount={() => setView('home')}
      />
    );
  }

  return (
    <EventsView
      age={selectedAge!}
      events={filteredEvents}
      totalCount={events.length}
      maxPrice={maxPrice}
      onMaxPriceChange={setMaxPrice}
      loading={loading}
      error={error}
      onBack={handleBackHome}
      onEventClick={handleEventClick}
      onSwitchAge={handleSelectAge}
      onCreateClick={() => setShowCreate(true)}
    >
      {showDetail && selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          loading={detailLoading}
          canDelete={selectedEvent.created_by === profile.id}
          onClose={() => {
            setShowDetail(false);
            setSelectedEvent(null);
          }}
          onDelete={() => handleEventDeleted(selectedEvent.id)}
        />
      )}
      {showCreate && (
        <CreateEventModal
          defaultAge={selectedAge!}
          profileId={profile.id}
          onClose={() => setShowCreate(false)}
          onCreated={handleEventCreated}
        />
      )}
    </EventsView>
  );
}

function HomeView({ onSelectAge, profile, onSignOut, onOpenProfile, onOpenCreators }: { onSelectAge: (age: AgeGroup) => void; profile: Profile; onSignOut: () => void; onOpenProfile: () => void; onOpenCreators: () => void }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, #60a5fa 0, transparent 40%), radial-gradient(circle at 80% 60%, #34d399 0, transparent 40%), radial-gradient(circle at 50% 100%, #fb923c 0, transparent 40%)' }} />
        {/* Welcome + profile + sign out */}
        <div className="absolute top-6 right-6 z-10 flex items-center gap-3">
          <button
            onClick={onOpenCreators}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur border border-white/15 text-white/90 text-sm font-medium hover:bg-white/20 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">About the Creators</span>
            <span className="sm:hidden">Creators</span>
          </button>
          <span className="text-white/90 text-sm font-medium hidden sm:inline">
            Hi, {profile.is_guest ? 'Guest' : profile.name.split(' ')[0]}!
          </span>
          <button
            onClick={onOpenProfile}
            className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-white/10 backdrop-blur border border-white/15 hover:bg-white/20 transition-colors overflow-hidden"
            aria-label="Your profile"
          >
            {profile.avatar_url ? (
              <img src={profile.avatar_url} alt={profile.name} className="w-full h-full object-cover" />
            ) : (
              <UserCircle className="w-5 h-5 text-white/90" />
            )}
          </button>
          <button
            onClick={onSignOut}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur border border-white/15 text-white/90 text-sm font-medium hover:bg-white/20 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Sign out</span>
          </button>
        </div>
        <div className="relative max-w-6xl mx-auto px-6 pt-20 pb-24 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur border border-white/15 text-white/90 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Your neighborhood, all ages
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight leading-tight">
            Heyborhood
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/70 max-w-2xl mx-auto">
            Pick your age group and discover events happening near you, picked for you.
          </p>
          <p className="mt-6 text-white/50 text-sm uppercase tracking-widest font-semibold">
            Who are you planning for?
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 -mt-16 pb-20 relative">
        <div className="grid md:grid-cols-3 gap-6">
          {AGE_GROUPS.map((group, i) => (
            <button
              key={group.id}
              onClick={() => onSelectAge(group.id)}
              className="group relative text-left rounded-3xl bg-white shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden hover:-translate-y-1.5 focus:outline-none focus:ring-4 focus:ring-slate-200"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className={`h-40 bg-gradient-to-br ${group.gradient} relative overflow-hidden`}>
                <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 30% 30%, white 0, transparent 50%)' }} />
                <div className="absolute bottom-4 left-5 text-5xl drop-shadow-md">{group.emoji}</div>
                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/25 backdrop-blur flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <ArrowRight className="w-5 h-5" />
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-baseline gap-2">
                  <h2 className="text-2xl font-bold text-slate-900">{group.label}</h2>
                  <span className={`text-sm font-semibold ${group.text}`}>{group.range}</span>
                </div>
                <p className="mt-2 text-slate-500 text-sm leading-relaxed">{group.description}</p>
                <div className={`mt-4 inline-flex items-center gap-1.5 text-sm font-semibold ${group.text}`}>
                  See events
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-16 grid sm:grid-cols-3 gap-4 text-center">
          <Stat value="18+" label="Local events" />
          <Stat value="3" label="Age groups" />
          <Stat value="Every week" label="New activities" />
        </div>
      </div>

      <footer className="border-t border-slate-200 py-8 text-center text-slate-400 text-sm">
        Heyborhood — bringing neighbors together, one event at a time.
      </footer>
    </div>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-2xl bg-white border border-slate-200 py-6 px-4">
      <div className="text-2xl font-bold text-slate-900">{value}</div>
      <div className="text-sm text-slate-500 mt-1">{label}</div>
    </div>
  );
}

interface EventsViewProps {
  age: AgeGroup;
  events: Event[];
  totalCount: number;
  maxPrice: number;
  onMaxPriceChange: (price: number) => void;
  loading: boolean;
  error: string | null;
  onBack: () => void;
  onEventClick: (event: Event) => void;
  onSwitchAge: (age: AgeGroup) => void;
  onCreateClick: () => void;
  children?: React.ReactNode;
}

function EventsView({
  age,
  events,
  totalCount,
  maxPrice,
  onMaxPriceChange,
  loading,
  error,
  onBack,
  onEventClick,
  onSwitchAge,
  onCreateClick,
  children,
}: EventsViewProps) {
  const info = getAgeGroupInfo(age);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-2 text-slate-700 hover:text-slate-900 font-semibold transition-colors">
            <span className="text-xl">🏠</span>
            <span className="hidden sm:inline">Heyborhood</span>
          </button>
          <div className="flex items-center gap-1.5 bg-slate-100 rounded-full p-1">
            {AGE_GROUPS.map((g) => (
              <button
                key={g.id}
                onClick={() => onSwitchAge(g.id)}
                className={`px-3 sm:px-4 py-1.5 rounded-full text-sm font-semibold transition-all ${
                  g.id === age ? 'bg-white text-slate-900 shadow' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <span className="sm:hidden">{g.emoji}</span>
                <span className="hidden sm:inline">{g.label}</span>
              </button>
            ))}
          </div>
          <button
            onClick={onCreateClick}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add event</span>
          </button>
        </div>
      </header>

      <div className={`h-40 bg-gradient-to-br ${info.gradient} relative overflow-hidden`}>
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 70% 20%, white 0, transparent 50%)' }} />
        <div className="absolute inset-0 flex items-center justify-between px-6 max-w-6xl mx-auto">
          <div>
            <div className="text-white/80 text-sm font-medium uppercase tracking-wider">{info.range}</div>
            <h1 className="text-4xl font-bold text-white mt-1 flex items-center gap-2">
              <span>{info.emoji}</span> {info.label} events
            </h1>
          </div>
          <div className="text-6xl opacity-30 hidden sm:block">{info.emoji}</div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-6 py-8">
        {!loading && !error && totalCount > 0 && (
          <div className="mb-6">
            <PriceRangeSlider
              events={events}
              maxPrice={maxPrice}
              onMaxPriceChange={onMaxPriceChange}
            />
          </div>
        )}

        {loading && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="rounded-2xl bg-white border border-slate-200 overflow-hidden animate-pulse">
                <div className="h-44 bg-slate-200" />
                <div className="p-5 space-y-3">
                  <div className="h-4 bg-slate-200 rounded w-1/3" />
                  <div className="h-5 bg-slate-200 rounded w-3/4" />
                  <div className="h-4 bg-slate-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        )}

        {error && (
          <div className="rounded-2xl bg-red-50 border border-red-200 p-6 flex items-start gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold">Couldn't load events</p>
              <p className="text-sm mt-1">{error}</p>
            </div>
          </div>
        )}

        {!loading && !error && totalCount === 0 && (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">📭</div>
            <h2 className="text-xl font-bold text-slate-900">No events yet</h2>
            <p className="text-slate-500 mt-2">Be the first to add an event for {info.label.toLowerCase()}.</p>
            <button
              onClick={onCreateClick}
              className="mt-6 inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors"
            >
              <Plus className="w-4 h-4" /> Add the first event
            </button>
          </div>
        )}

        {!loading && !error && events.length === 0 && totalCount > 0 && (
          <div className="text-center py-16">
            <div className="text-4xl mb-3">🔍</div>
            <h2 className="text-lg font-bold text-slate-900">No events in this price range</h2>
            <p className="text-slate-500 mt-1 text-sm">Try increasing the max price.</p>
          </div>
        )}

        {!loading && !error && events.length > 0 && (
          <>
            <div className="flex items-center justify-between mb-5">
              <p className="text-slate-500 text-sm">
                <span className="font-bold text-slate-900">{events.length}</span> of {totalCount} event{totalCount !== 1 ? 's' : ''} coming up
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {events.map((event) => (
                <EventCard key={event.id} event={event} onClick={() => onEventClick(event)} />
              ))}
            </div>
          </>
        )}
      </main>

      {children}
    </div>
  );
}

function EventCard({ event, onClick }: { event: Event; onClick: () => void }) {
  const info = getAgeGroupInfo(event.age_group);
  return (
    <button
      onClick={onClick}
      className="group text-left rounded-2xl bg-white border border-slate-200 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-slate-300"
    >
      <div className="relative h-44 overflow-hidden bg-slate-100">
        {event.image_url ? (
          <img
            src={event.image_url}
            alt={event.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className={`w-full h-full bg-gradient-to-br ${info.gradient}`} />
        )}
        {event.category && (
          <span className={`absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-semibold text-white bg-slate-900/70 backdrop-blur`}>
            {event.category}
          </span>
        )}
        <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs font-bold text-white bg-white/20 backdrop-blur">
          {event.price ?? 'Free'}
        </span>
      </div>
      <div className="p-5">
        <h3 className="font-bold text-lg text-slate-900 leading-tight group-hover:text-slate-700">{event.title}</h3>
        <div className="mt-3 space-y-1.5 text-sm text-slate-500">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <span>{formatDate(event.date)}</span>
            {event.time && (
              <>
                <span className="text-slate-300">•</span>
                <Clock className="w-4 h-4 text-slate-400 flex-shrink-0" />
                <span>{event.time}</span>
              </>
            )}
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <span className="truncate">{event.location}</span>
          </div>
        </div>
      </div>
    </button>
  );
}

function EventDetailModal({
  event,
  loading,
  canDelete,
  onClose,
  onDelete,
}: {
  event: Event;
  loading: boolean;
  canDelete: boolean;
  onClose: () => void;
  onDelete: () => void;
}) {
  const info = getAgeGroupInfo(event.age_group);
  const [confirmDelete, setConfirmDelete] = useState(false);

  return (
    <Modal onClose={onClose}>
      <div className="relative">
        <div className="relative h-56 overflow-hidden rounded-t-2xl bg-slate-100">
          {event.image_url ? (
            <img src={event.image_url} alt={event.title} className="w-full h-full object-cover" />
          ) : (
            <div className={`w-full h-full bg-gradient-to-br ${info.gradient}`} />
          )}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-black/40 backdrop-blur text-white flex items-center justify-center hover:bg-black/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="absolute bottom-3 left-3 flex gap-2">
            {event.category && (
              <span className="px-3 py-1 rounded-full text-xs font-semibold text-white bg-slate-900/70 backdrop-blur">
                {event.category}
              </span>
            )}
            <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${info.bg} ${info.text}`}>
              {info.label}
            </span>
          </div>
        </div>

        {loading ? (
          <div className="p-6 space-y-3 animate-pulse">
            <div className="h-6 bg-slate-200 rounded w-2/3" />
            <div className="h-4 bg-slate-200 rounded w-1/2" />
            <div className="h-20 bg-slate-200 rounded" />
          </div>
        ) : (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-slate-900">{event.title}</h2>
            <div className="mt-4 grid sm:grid-cols-2 gap-3">
              <InfoRow icon={<Calendar className="w-4 h-4" />} label="Date" value={formatLongDate(event.date)} />
              {event.time && <InfoRow icon={<Clock className="w-4 h-4" />} label="Time" value={event.time} />}
              <InfoRow icon={<MapPin className="w-4 h-4" />} label="Location" value={event.location} />
              <InfoRow icon={<Tag className="w-4 h-4" />} label="Price" value={event.price ?? 'Free'} />
            </div>
            {event.description && (
              <div className="mt-5">
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-2">About this event</h3>
                <p className="text-slate-700 leading-relaxed">{event.description}</p>
              </div>
            )}

            <div className="mt-6 flex items-center justify-between">
              {canDelete ? (
                <button
                  onClick={() => setConfirmDelete(true)}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-red-600 hover:text-red-700 transition-colors"
                >
                  <Trash2 className="w-4 h-4" /> Remove event
                </button>
              ) : (
                <span className="text-xs text-slate-400">You can only remove events you created.</span>
              )}
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-full bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 transition-colors"
              >
                Got it
              </button>
            </div>

            {confirmDelete && (
              <div className="mt-4 p-4 rounded-xl bg-red-50 border border-red-200">
                <p className="text-sm text-red-700 font-medium">Remove this event? This can't be undone.</p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={onDelete}
                    className="px-4 py-1.5 rounded-lg bg-red-600 text-white text-sm font-semibold hover:bg-red-700 transition-colors"
                  >
                    Yes, remove
                  </button>
                  <button
                    onClick={() => setConfirmDelete(false)}
                    className="px-4 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}

function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50">
      <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-500 flex-shrink-0">
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{label}</div>
        <div className="text-sm font-medium text-slate-800 truncate">{value}</div>
      </div>
    </div>
  );
}

function CreateEventModal({
  defaultAge,
  profileId,
  onClose,
  onCreated,
}: {
  defaultAge: AgeGroup;
  profileId: string;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ageGroup, setAgeGroup] = useState<AgeGroup>(defaultAge);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState('');
  const [price, setPrice] = useState('Free');
  const [imageUrl, setImageUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !date || !location) {
      setError('Please fill in the title, date, and location.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await createEvent({
        title,
        description: description || null,
        age_group: ageGroup,
        date,
        time: time || null,
        location,
        image_url: imageUrl || null,
        category: category || null,
        price: price || 'Free',
        created_by: profileId,
      });
      onCreated();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create event');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal onClose={onClose} maxWidth="max-w-lg">
      <div className="p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Plus className="w-5 h-5 text-slate-500" /> Add a new event
          </h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Title" required>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={inputClass}
              placeholder="e.g. Sunday Farmers Market"
              required
            />
          </Field>

          <Field label="Description">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={`${inputClass} min-h-[80px] resize-y`}
              placeholder="What's happening? What should people know?"
            />
          </Field>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Age group" required>
              <select value={ageGroup} onChange={(e) => setAgeGroup(e.target.value as AgeGroup)} className={inputClass}>
                {AGE_GROUPS.map((g) => (
                  <option key={g.id} value={g.id}>{g.label} ({g.range})</option>
                ))}
              </select>
            </Field>
            <Field label="Category">
              <input
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className={inputClass}
                placeholder="Sports, Music, Arts..."
              />
            </Field>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Date" required>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputClass} required />
            </Field>
            <Field label="Time">
              <input
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className={inputClass}
                placeholder="e.g. 2:00 PM"
              />
            </Field>
          </div>

          <Field label="Location" required>
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className={inputClass}
              placeholder="e.g. Riverside Community Center"
              required
            />
          </Field>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Price">
              <input
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className={inputClass}
                placeholder="Free, $5, $20..."
              />
            </Field>
            <Field label="Image URL">
              <input
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className={inputClass}
                placeholder="https://..."
              />
            </Field>
          </div>

          {error && (
            <div className="rounded-xl bg-red-50 border border-red-200 p-3 flex items-start gap-2 text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              {error}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-full border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-full bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 transition-colors disabled:opacity-50"
            >
              {submitting ? 'Adding...' : 'Add event'}
            </button>
          </div>
        </form>
      </div>
    </Modal>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-700 mb-1.5 block">
        {label}{required && <span className="text-red-500"> *</span>}
      </span>
      {children}
    </label>
  );
}

const inputClass =
  'w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-slate-300 focus:border-transparent transition-all placeholder:text-slate-400';

function Modal({
  children,
  onClose,
  maxWidth = 'max-w-xl',
}: {
  children: React.ReactNode;
  onClose: () => void;
  maxWidth?: string;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn"
      onClick={onClose}
    >
      <div
        className={`w-full ${maxWidth} max-h-[90vh] overflow-y-auto rounded-2xl bg-white shadow-2xl animate-scaleIn`}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}
