import { useState } from 'react';
import marthaPhoto from '@/assets/creators/Screenshot_2026-07-30_115929 copy.png';
import taynahPhoto from '@/assets/creators/Screenshot_2026-07-30_121846.png';
import {
  ArrowLeft, Github, ExternalLink, ChevronLeft, ChevronRight,
  Palette, Cpu, User, Sparkles, Leaf, Music, Code2,
} from 'lucide-react';

interface Props {
  onBack: () => void;
}

type CreatorId = 'martha' | 'taynah' | 'amarieh';

interface Link { label: string; url: string; }
interface Qual { label: string; detail: string; icon: React.ReactNode; }

interface Creator {
  id: CreatorId;
  name: string;
  role: string;
  shortTag: string;
  about: string;
  tech?: string;
  skills?: string;
  qualifications?: Qual[];
  links: Link[];
  photo?: string;
}

const creators: Creator[] = [
  {
    id: 'martha',
    name: 'Martha Desir',
    role: 'Creator',
    shortTag: 'Gamer · Anime · Coder',
    about: "Hi! My name is Martha I am 16 years old. I was born in East Orange New Jersey. I am set to graduate year 2028. I currently attend Newark Collegiate Academy. Things that I like to do is play genshin, play roblox watch anime, hangout with my friends and help the teachers around my school.",
    tech: "I have been recommended for AP computer science twice. I have coded multiple apps. I very familiar with how code.org works and I have used it countless of times to code for the CSP class or AP World class.",
    links: [{ label: 'GitHub', url: 'https://github.com/marthadeeesir' }],
    photo: marthaPhoto,
  },
  {
    id: 'taynah',
    name: 'Taynah Mollo',
    role: 'Creator',
    shortTag: 'Musician · Gamer · Coder',
    about: "I am a 17 year old, and I was born in Newark New Jersey. I graduate in the year 2027, and I attend Science Park High School. I have always been interested in how technology works, more specifically coding and cyber security as well. I like many shows such as AP Bio, Brooklyn 99, Abbott Elementary, Amphibia, Infinity Train, The Amazing World of Gumball, etc., and play video games such as Roblox, Minecraft, Cuphead, My Singing Monsters.",
    skills: "I am a decent cymbal player, part of a marching band. I can read sheet music fairly well. I also know python from computer class. I originally started learning with block code. Though I am familiar with SOME code, I still am eager to learn more about it in the future, starting with learning more HTML and CSS.",
    links: [{ label: 'GitHub', url: 'https://github.com/taynahm1128/taynahm1128-portfolio.git' }],
    photo: taynahPhoto,
  },
  {
    id: 'amarieh',
    name: 'Amarieh H',
    role: 'Creator',
    shortTag: 'Designer · Autodesk · Tech',
    about: "Hello! My name is Amarieh Hughes. I am a teenager starting to learn her way around the world of technology. I first became interested in the world of technology one day when I was watching Criminal Minds with my mom and Penelope Garcia came onto the screen. I saw what she was doing and how she was able to help people and save lives even without being in the field which corresponds with one of my values of being helpful. Throughout my childhood and even now I am still the person my family comes to when they have tech issues.",
    qualifications: [
      { label: 'Aesthetics', detail: "I have been complimented on my creativity on school projects many times not only throughout highschool but from elementary", icon: <Palette className="w-5 h-5" /> },
      { label: 'Autodesk Certified', detail: "I passed my Autodesk certification test. An Autodesk certification is an official, industry-recognized credential that proves proficiency in using Autodesk Software", icon: <Cpu className="w-5 h-5" /> },
    ],
    links: [
      { label: 'GitHub', url: 'https://github.com/Techy-Astar/Techy-Astar' },
      { label: 'Canva', url: 'https://canva.link/4r94xqo8y4m8uut' },
    ],
    photo: '/assets/profiles/Screenshot_2026-07-30_121858.png',
  },
];

export default function CreatorsView({ onBack }: Props) {
  const [active, setActive] = useState(0);
  const creator = creators[active];
  const prev = () => setActive((a) => (a - 1 + creators.length) % creators.length);
  const next = () => setActive((a) => (a + 1) % creators.length);

  return (
    <div className="min-h-screen transition-colors duration-700">
      <style>{`
        @keyframes slideUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes slideInLeft { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes slideInRight { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes pop { from { opacity: 0; transform: scale(0.92); } to { opacity: 1; transform: scale(1); } }
        @keyframes glitch { 0%,100% { transform: translate(0); } 20% { transform: translate(-1px,1px); } 40% { transform: translate(1px,-1px); } 60% { transform: translate(-1px,0); } 80% { transform: translate(1px,1px); } }
      `}</style>

      {/* Universal top bar */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/20 border-b border-white/30">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
          <button onClick={onBack} className="flex items-center gap-2 font-semibold text-slate-700 hover:opacity-70 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back to Heyborhood</span>
            <span className="sm:hidden">Back</span>
          </button>
          <h1 className="font-bold text-slate-700">About the Creators</h1>
        </div>
      </header>

      {/* Creator selector tabs */}
      <div className="max-w-5xl mx-auto px-6 pt-8 pb-6">
        <div className="flex gap-3 justify-center flex-wrap">
          {creators.map((c, i) => (
            <button
              key={c.id}
              onClick={() => setActive(i)}
              className={`px-6 py-2.5 text-sm font-bold transition-all duration-300 ${
                i === active
                  ? 'text-white scale-105 shadow-lg'
                  : 'bg-white/50 text-slate-600 hover:bg-white/70'
              } ${i === active ? accentBar(i) : ''}`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Active creator layout */}
      <div key={creator.id}>
        {creator.id === 'martha' && <MarthaLayout creator={creator} prev={prev} next={next} />}
        {creator.id === 'taynah' && <TaynahLayout creator={creator} prev={prev} next={next} />}
        {creator.id === 'amarieh' && <AmariehLayout creator={creator} prev={prev} next={next} />}
      </div>

      {/* Pagination dots */}
      <div className="flex justify-center gap-2 pb-10">
        {creators.map((_, i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            className={`rounded-full transition-all duration-300 ${i === active ? `w-8 h-2.5 ${dotBg(i)}` : 'w-2.5 h-2.5 bg-black/20 hover:bg-black/40'}`}
            aria-label={`View creator ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}

function accentBar(i: number) {
  return ['bg-[#0a5a6e]', 'bg-[#8a6d1a]', 'bg-[#ad1f63]'][i] || '';
}
function dotBg(i: number) {
  return ['bg-[#0a5a6e]', 'bg-[#8a6d1a]', 'bg-[#ad1f63]'][i] || '';
}

/* =================== MARTHA — Botanical Magazine Spread =================== */
function MarthaLayout({ creator, prev, next }: { creator: Creator; prev: () => void; next: () => void; }) {
  return (
    <div className="min-h-[70vh] bg-gradient-to-br from-[#a8e6cf] via-[#c4f0d8] to-[#e0f5e9] pb-16">
      <div className="max-w-5xl mx-auto px-6">
        <div
          className="relative bg-white/40 backdrop-blur-sm rounded-[2.5rem] border-2 border-white/60 shadow-2xl overflow-hidden"
          style={{ animation: 'slideUp 0.5s ease both' }}
        >
          {/* Floating decorative blobs */}
          <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-[#7fd1b0]/30 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-16 w-60 h-60 rounded-full bg-[#a8e6cf]/40 blur-3xl pointer-events-none" />

          {/* Magazine-style header: photo left, big serif name right */}
          <div className="relative grid md:grid-cols-2 gap-0 items-stretch">
            <div className="relative p-10 flex flex-col justify-center order-2 md:order-1" style={{ animation: 'slideInLeft 0.5s ease both' }}>
              <span className="inline-flex items-center gap-1.5 text-[#0a5a6e]/70 font-semibold text-sm mb-3">
                <Leaf className="w-4 h-4" /> {creator.shortTag}
              </span>
              <h2 className="font-serif text-5xl md:text-6xl text-[#074a5e] leading-[1.05]">{creator.name}</h2>
              <p className="font-serif italic text-2xl text-[#0a5a6e] mt-2">{creator.role}</p>
              <div className="flex gap-2 mt-5">
                <NavBtn dir="prev" onClick={prev} color="#0a5a6e" />
                <NavBtn dir="next" onClick={next} color="#0a5a6e" />
              </div>
            </div>
            <div className="relative order-1 md:order-2 p-6 flex items-center justify-center bg-[#c4f0d8]/40" style={{ animation: 'slideInRight 0.5s ease both' }}>
              <div className="w-48 h-48 md:w-60 md:h-60 rounded-full ring-8 ring-white/80 shadow-2xl overflow-hidden">
                {creator.photo
                  ? <img src={creator.photo} alt={creator.name} className="w-full h-full object-cover" />
                  : <div className="w-full h-full bg-[#0a5a6e] flex items-center justify-center text-white"><User className="w-20 h-20" /></div>}
              </div>
              <Sparkles className="absolute top-10 right-10 w-8 h-8 text-[#0a5a6e]/30" />
              <Sparkles className="absolute bottom-12 left-8 w-6 h-6 text-[#0a5a6e]/20" />
            </div>
          </div>

          {/* Content: two columns */}
          <div className="relative px-10 pb-12 pt-2 grid md:grid-cols-2 gap-8" style={{ animation: 'slideUp 0.6s ease both' }}>
            <div className="rounded-3xl bg-white/50 border border-white/70 p-7">
              <h3 className="font-serif text-xl text-[#074a5e] mb-3">About Me</h3>
              <p className="text-[#0a5a6e] leading-relaxed">{creator.about}</p>
            </div>
            <div className="rounded-3xl bg-white/50 border border-white/70 p-7">
              <h3 className="font-serif text-xl text-[#074a5e] mb-3 flex items-center gap-2"><Code2 className="w-5 h-5" /> Tech</h3>
              <p className="text-[#0a5a6e] leading-relaxed">{creator.tech}</p>
            </div>
          </div>

          {/* Links as pill chips */}
          <div className="relative px-10 pb-10 flex flex-wrap gap-3">
            {creator.links.map((l, i) => (
              <a key={i} href={l.url} target="_blank" rel="noopener noreferrer"
                 className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#0a5a6e] text-[#a8e6cf] font-semibold hover:scale-105 hover:shadow-lg transition-all">
                {l.label === 'GitHub' ? <Github className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
                {l.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* =================== TAYNAH — Vintage Scrapbook =================== */
function TaynahLayout({ creator, prev, next }: { creator: Creator; prev: () => void; next: () => void; }) {
  return (
    <div className="min-h-[70vh] bg-[#f5e7c8] pb-16">
      {/* Paper texture overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-30" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%224%22 height=%224%22%3E%3Crect width=%224%22 height=%224%22 fill=%22%23e8d5a3%22/%3E%3Crect width=%221%22 height=%221%22 fill=%22%23d4c088%22/%3E%3C/svg%3E")' }} />

      <div className="max-w-5xl mx-auto px-6 relative">
        <div
          className="relative bg-[#fffdf3] rounded-2xl border-2 border-[#d4b87a] shadow-[0_12px_50px_rgba(138,109,26,0.2)] overflow-hidden"
          style={{ animation: 'pop 0.5s ease both', transform: 'rotate(-0.4deg)' }}
        >
          {/* Torn tape decoration */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-32 h-8 bg-[#e8c878]/70 rotate-2 shadow-sm" style={{ backgroundImage: 'repeating-linear-gradient(90deg, transparent 0 8px, rgba(0,0,0,0.04) 8px 9px)' }} />

          {/* Scrapbook header: photo in polaroid frame, name in stamp style */}
          <div className="relative px-8 md:px-12 pt-12 pb-8">
            <div className="flex flex-col md:flex-row items-center gap-8">
              {/* Polaroid */}
              <div className="bg-white p-3 pb-12 shadow-xl rotate-[-3deg] flex-shrink-0" style={{ animation: 'slideInLeft 0.5s ease both' }}>
                <div className="w-40 h-40 bg-[#f5e7c8] overflow-hidden">
                  {creator.photo
                    ? <img src={creator.photo} alt={creator.name} className="w-full h-full object-cover" />
                    : <div className="w-full h-full bg-[#8a6d1a] flex items-center justify-center text-white"><User className="w-16 h-16" /></div>}
                </div>
                <p className="font-mono text-xs text-[#8a6d1a] text-center mt-2 rotate-[-1deg]">~ taynah ~</p>
              </div>

              {/* Name block */}
              <div className="flex-1 text-center md:text-left" style={{ animation: 'slideInRight 0.5s ease both' }}>
                <div className="inline-block border-2 border-[#8a6d1a] px-5 py-2 rotate-[-1deg] mb-3">
                  <span className="font-mono text-sm text-[#8a6d1a] font-bold">{creator.shortTag}</span>
                </div>
                <h2 className="font-mono text-4xl md:text-5xl text-[#7a5c0a] font-bold">{creator.name}</h2>
                <p className="font-mono italic text-xl text-[#b8860b] mt-2">{creator.role}</p>
                <div className="flex gap-2 mt-5 justify-center md:justify-start">
                  <NavBtn dir="prev" onClick={prev} color="#8a6d1a" />
                  <NavBtn dir="next" onClick={next} color="#8a6d1a" />
                </div>
              </div>
            </div>
          </div>

          {/* Scrapbook content cards with slight rotations */}
          <div className="relative px-8 md:px-12 pb-10 space-y-8">
            <ScrapCard label="About Me" icon={<User className="w-4 h-4" />} rotate={0.6}>
              <p className="text-[#5a4a0a] leading-relaxed font-mono text-sm">{creator.about}</p>
            </ScrapCard>

            {creator.skills && (
              <ScrapCard label="Skills" icon={<Music className="w-4 h-4" />} rotate={-0.8}>
                <p className="text-[#5a4a0a] leading-relaxed font-mono text-sm">{creator.skills}</p>
              </ScrapCard>
            )}

            {/* Links pinned to bottom */}
            <div className="pt-4 flex flex-wrap gap-4">
              {creator.links.map((l, i) => (
                <a key={i} href={l.url} target="_blank" rel="noopener noreferrer"
                   className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#8a6d1a] text-[#fdf6d8] font-mono font-bold text-sm shadow-md hover:scale-105 transition-all"
                   style={{ transform: `rotate(${i % 2 === 0 ? 1 : -1}deg)` }}>
                  {l.label === 'GitHub' ? <Github className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
                  {l.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScrapCard({ label, icon, rotate, children }: { label: string; icon: React.ReactNode; rotate: number; children: React.ReactNode }) {
  return (
    <div
      className="bg-[#fffdf3]/80 border-2 border-dashed border-[#d4b87a] p-6 shadow-md"
      style={{ transform: `rotate(${rotate}deg)`, animation: 'pop 0.6s ease both' }}
    >
      <div className="flex items-center gap-2 mb-3">
        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#8a6d1a] text-[#fdf6d8]">{icon}</span>
        <h3 className="font-mono text-lg text-[#7a5c0a] font-bold tracking-wide">{label}</h3>
      </div>
      {children}
    </div>
  );
}

/* =================== AMARIEH — Dark Tech Dashboard =================== */
function AmariehLayout({ creator, prev, next }: { creator: Creator; prev: () => void; next: () => void; }) {
  return (
    <div className="min-h-[70vh] bg-[#1a0a14] pb-16">
      {/* Grid background */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.07]"
        style={{ backgroundImage: 'linear-gradient(rgba(173,31,99,0.8) 1px, transparent 1px), linear-gradient(90deg, rgba(173,31,99,0.8) 1px, transparent 1px)', backgroundSize: '40px 40px' }}
      />

      <div className="max-w-5xl mx-auto px-6 relative">
        <div
          className="bg-[#220e1c] border border-[#ad1f63]/30 shadow-[0_0_60px_rgba(173,31,99,0.15)] overflow-hidden"
          style={{ animation: 'slideUp 0.5s ease both' }}
        >
          {/* Terminal-style header bar */}
          <div className="flex items-center gap-2 px-5 py-3 bg-[#2a1220] border-b border-[#ad1f63]/20">
            <span className="w-3 h-3 rounded-full bg-[#ad1f63]/60" />
            <span className="w-3 h-3 rounded-full bg-[#f5b04d]/50" />
            <span className="w-3 h-3 rounded-full bg-[#7fd1b0]/50" />
            <span className="font-mono text-xs text-[#ad1f63]/60 ml-2">~/creators/amarieh — profile.json</span>
          </div>

          {/* Dashboard layout: sidebar + main */}
          <div className="grid md:grid-cols-[260px_1fr] gap-0">
            {/* Sidebar */}
            <div className="p-8 border-r border-[#ad1f63]/20 flex flex-col items-center text-center" style={{ animation: 'slideInLeft 0.5s ease both' }}>
              <div className="w-32 h-32 rounded-xl border-2 border-[#ad1f63]/40 overflow-hidden mb-4 shadow-[0_0_30px_rgba(173,31,99,0.2)]">
                {creator.photo
                  ? <img src={creator.photo} alt={creator.name} className="w-full h-full object-cover" />
                  : <div className="w-full h-full bg-[#ad1f63] flex items-center justify-center text-white"><User className="w-12 h-12" /></div>}
              </div>
              <h2 className="font-mono text-2xl text-[#ff5fa2] font-bold">{creator.name}</h2>
              <p className="font-mono text-sm text-[#0e7c9b] mt-1">&gt; {creator.role}</p>
              <div className="mt-3 px-3 py-1 rounded bg-[#ad1f63]/15 border border-[#ad1f63]/30">
                <span className="font-mono text-xs text-[#ff5fa2]">{creator.shortTag}</span>
              </div>
              <div className="flex gap-2 mt-6">
                <NavBtn dir="prev" onClick={prev} color="#ff5fa2" dark />
                <NavBtn dir="next" onClick={next} color="#ff5fa2" dark />
              </div>
            </div>

            {/* Main content */}
            <div className="p-8 space-y-6" style={{ animation: 'slideInRight 0.5s ease both' }}>
              {/* About — terminal block style */}
              <div className="rounded-lg border-l-2 border-[#ad1f63] bg-[#1a0a14]/60 p-5">
                <h3 className="font-mono text-sm uppercase tracking-[0.2em] text-[#0e7c9b] mb-3">// About_Me</h3>
                <p className="text-[#f8e0ec] leading-relaxed font-mono text-sm">{creator.about}</p>
              </div>

              {/* Qualifications — stat cards */}
              {creator.qualifications && (
                <div>
                  <h3 className="font-mono text-sm uppercase tracking-[0.2em] text-[#0e7c9b] mb-3">// Qualifications</h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {creator.qualifications.map((q, i) => (
                      <div key={i} className="rounded-lg bg-[#2a1220] border border-[#ad1f63]/25 p-5 hover:border-[#ad1f63]/50 transition-colors" style={{ animation: `pop 0.5s ease ${i * 0.1}s both` }}>
                        <div className="flex items-center gap-2 mb-2 text-[#ff5fa2]">
                          {q.icon}
                          <h4 className="font-mono font-bold text-sm">{q.label}</h4>
                        </div>
                        <p className="text-[#f8e0ec]/80 text-sm leading-relaxed font-mono">{q.detail}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Links — button row */}
              <div className="pt-2">
                <h3 className="font-mono text-sm uppercase tracking-[0.2em] text-[#0e7c9b] mb-3">// Links</h3>
                <div className="flex flex-wrap gap-3">
                  {creator.links.map((l, i) => (
                    <a key={i} href={l.url} target="_blank" rel="noopener noreferrer"
                       className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#ad1f63] text-white font-mono font-bold text-sm hover:bg-[#c4387a] hover:shadow-[0_0_20px_rgba(173,31,99,0.4)] transition-all">
                      {l.label === 'GitHub' ? <Github className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
                      {l.label}
                      <span className="text-white/50">↗</span>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =================== Shared nav button =================== */
function NavBtn({ dir, onClick, color, dark }: { dir: 'prev' | 'next'; onClick: () => void; color: string; dark?: boolean }) {
  return (
    <button
      onClick={onClick}
      aria-label={dir === 'prev' ? 'Previous creator' : 'Next creator'}
      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110 ${dark ? 'bg-white/10 hover:bg-white/20' : 'bg-white/60 hover:bg-white'}`}
      style={{ color }}
    >
      {dir === 'prev' ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
    </button>
  );
}
