import { useState } from 'react';
import { ArrowLeft, Camera, Check, Loader2, AlertCircle, UserPlus, Users, Sparkles, UserCircle } from 'lucide-react';
import type { Profile } from '../lib/supabase';
import { updateProfile, createProfile, fetchProfiles, getStoredProfileIds, switchStoredProfileId } from '../lib/profiles';
import { ACTIVITIES, getActivityLabel } from '../lib/activities';

const AVATAR_PRESETS = [
  'https://images.pexels.com/photos/35490803/pexels-photo-35490803.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/14950779/pexels-photo-14950779.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/16869444/pexels-photo-16869444.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/35681211/pexels-photo-35681211.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/6102841/pexels-photo-6102841.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/5308640/pexels-photo-5308640.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/35490806/pexels-photo-35490806.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
  'https://images.pexels.com/photos/34930167/pexels-photo-34930167.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
];

interface ProfileViewProps {
  profile: Profile;
  onBack: () => void;
  onProfileChange: (profile: Profile) => void;
  onAddAccount: () => void;
}

export default function ProfileView({ profile, onBack, onProfileChange, onAddAccount }: ProfileViewProps) {
  const [name, setName] = useState(profile.name);
  const [age, setAge] = useState(profile.age?.toString() ?? '');
  const [avatarUrl, setAvatarUrl] = useState(profile.avatar_url ?? '');
  const [selectedActivities, setSelectedActivities] = useState<string[]>(profile.preferred_activities ?? []);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  // account switcher
  const [accounts, setAccounts] = useState<Profile[]>([profile]);
  const [loadingAccounts, setLoadingAccounts] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newAge, setNewAge] = useState('');
  const [creating, setCreating] = useState(false);

  const toggleActivity = (id: string) => {
    setSelectedActivities((prev) => (prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      const updated = await updateProfile(profile.id, {
        name: name.trim() || profile.name,
        age: age.trim() ? parseInt(age, 10) : null,
        avatar_url: avatarUrl || null,
        preferred_activities: selectedActivities,
      });
      onProfileChange(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save your profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleSwitchAccount = async (id: string) => {
    if (id === profile.id) return;
    setLoadingAccounts(true);
    try {
      switchStoredProfileId(id);
      const found = await fetchProfiles([id]);
      if (found[0]) onProfileChange(found[0]);
    } catch {
      setError('Could not switch accounts.');
    } finally {
      setLoadingAccounts(false);
    }
  };

  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setCreating(true);
    setError(null);
    try {
      const created = await createProfile({ name: newName.trim(), is_guest: false });
      const fresh = await fetchProfiles(getStoredProfileIds());
      setAccounts(fresh);
      setShowAddForm(false);
      setNewName('');
      setNewAge('');
      onProfileChange(created);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create the account.');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-2 text-slate-700 hover:text-slate-900 font-semibold transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <h1 className="font-bold text-slate-900">Your profile</h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        {/* Identity card */}
        <form onSubmit={handleSave} className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden">
          <div className="h-24 bg-gradient-to-r from-blue-500 via-emerald-400 to-amber-400" />
          <div className="px-6 pb-6">
            <div className="flex items-end justify-between -mt-12">
              <div className="relative">
                {avatarUrl ? (
                  <img src={avatarUrl} alt={name} className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg" />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-slate-100 border-4 border-white shadow-lg flex items-center justify-center text-slate-300">
                    <UserCircle className="w-12 h-12" />
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => setShowAvatarPicker((v) => !v)}
                  className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-md hover:bg-slate-800 transition-colors"
                  aria-label="Choose profile picture"
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>
            </div>

            {showAvatarPicker && (
              <div className="mt-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Pick a profile picture</p>
                <div className="grid grid-cols-4 gap-3">
                  {AVATAR_PRESETS.map((url) => (
                    <button
                      key={url}
                      type="button"
                      onClick={() => {
                        setAvatarUrl(url);
                        setShowAvatarPicker(false);
                      }}
                      className={`rounded-xl overflow-hidden border-2 transition-all ${
                        avatarUrl === url ? 'border-slate-900 ring-2 ring-slate-200' : 'border-transparent hover:border-slate-300'
                      }`}
                    >
                      <img src={url} alt="Avatar option" className="w-full h-full object-cover aspect-square" />
                    </button>
                  ))}
                </div>
                {avatarUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      setAvatarUrl('');
                      setShowAvatarPicker(false);
                    }}
                    className="mt-3 text-xs font-semibold text-slate-500 hover:text-slate-700"
                  >
                    Remove picture
                  </button>
                )}
              </div>
            )}

            <div className="mt-6 grid sm:grid-cols-2 gap-4">
              <label className="block">
                <span className="text-sm font-semibold text-slate-700 mb-1.5 block">Name</span>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={inputClass}
                  placeholder="Your name"
                />
              </label>
              <label className="block">
                <span className="text-sm font-semibold text-slate-700 mb-1.5 block">Age</span>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className={inputClass}
                  placeholder="Optional"
                />
              </label>
            </div>

            <div className="mt-6">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-slate-500" />
                <h2 className="text-sm font-bold text-slate-900">Preferred activities</h2>
              </div>
              <p className="text-xs text-slate-400 mb-3">Pick the things you love — we'll keep them in mind.</p>
              <div className="flex flex-wrap gap-2">
                {ACTIVITIES.map((a) => {
                  const active = selectedActivities.includes(a.id);
                  return (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => toggleActivity(a.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                        active
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <span>{a.emoji}</span>
                      {a.label}
                      {active && <Check className="w-3.5 h-3.5" />}
                    </button>
                  );
                })}
              </div>
              {selectedActivities.length > 0 && (
                <p className="mt-3 text-xs text-slate-500">
                  {selectedActivities.length} selected: {selectedActivities.map(getActivityLabel).join(', ')}
                </p>
              )}
            </div>

            {error && (
              <div className="mt-5 rounded-xl bg-red-50 border border-red-200 p-3 flex items-start gap-2 text-red-700 text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                {error}
              </div>
            )}

            <div className="mt-6 flex items-center justify-end gap-3">
              {saved && (
                <span className="text-sm font-semibold text-emerald-600 flex items-center gap-1.5">
                  <Check className="w-4 h-4" /> Saved
                </span>
              )}
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 transition-colors disabled:opacity-50"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Save changes
              </button>
            </div>
          </div>
        </form>

        {/* Accounts section */}
        <section className="rounded-3xl bg-white border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-slate-500" />
              <h2 className="text-sm font-bold text-slate-900">Accounts on this device</h2>
            </div>
            <button
              onClick={() => setShowAddForm((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-slate-300 text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors"
            >
              <UserPlus className="w-4 h-4" /> Add account
            </button>
          </div>

          {showAddForm && (
            <form onSubmit={handleCreateAccount} className="mb-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className={inputClass}
                  placeholder="Name for the new account"
                  required
                  autoFocus
                />
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={newAge}
                  onChange={(e) => setNewAge(e.target.value)}
                  className={inputClass}
                  placeholder="Age (optional)"
                />
              </div>
              <div className="flex items-center justify-end gap-2">
                <button type="button" onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-full border border-slate-300 text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors">
                  Cancel
                </button>
                <button type="submit" disabled={creating} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 transition-colors disabled:opacity-50">
                  {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                  Create
                </button>
              </div>
            </form>
          )}

          <ul className="space-y-2">
            {accounts.map((acc) => {
              const active = acc.id === profile.id;
              return (
                <li key={acc.id}>
                  <button
                    onClick={() => handleSwitchAccount(acc.id)}
                    disabled={loadingAccounts}
                    className={`w-full flex items-center gap-3 p-3 rounded-2xl border transition-all ${
                      active ? 'border-slate-900 bg-slate-50' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {acc.avatar_url ? (
                      <img src={acc.avatar_url} alt={acc.name} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                        <UserCircle className="w-6 h-6" />
                      </div>
                    )}
                    <div className="text-left min-w-0">
                      <div className="font-semibold text-slate-900 truncate">
                        {acc.name} {acc.is_guest && <span className="text-xs font-normal text-slate-400">(Guest)</span>}
                      </div>
                      {acc.age && <div className="text-xs text-slate-500">Age {acc.age}</div>}
                    </div>
                    {active && (
                      <span className="ml-auto text-xs font-semibold text-slate-900 bg-white border border-slate-200 px-2.5 py-1 rounded-full">
                        Active
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      </main>
    </div>
  );
}

const inputClass =
  'w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-slate-300 focus:border-transparent transition-all placeholder:text-slate-400';
