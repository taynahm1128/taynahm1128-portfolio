import { useMemo } from 'react';
import type { Event } from '../lib/supabase';
import { parsePrice } from '../lib/events';

interface PriceRangeSliderProps {
  events: Event[];
  maxPrice: number;
  onMaxPriceChange: (price: number) => void;
}

export default function PriceRangeSlider({ events, maxPrice, onMaxPriceChange }: PriceRangeSliderProps) {
  const stats = useMemo(() => {
    if (events.length === 0) return { min: 0, max: 0, avg: 0 };
    const prices = events.map((e) => parsePrice(e.price));
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const avg = Math.round(prices.reduce((a, b) => a + b, 0) / prices.length);
    return { min, max, avg };
  }, [events]);

  const sliderMax = Math.max(50, Math.ceil((stats.max + 5) / 5) * 5);
  const within = events.filter((e) => parsePrice(e.price) <= maxPrice).length;

  return (
    <div className="rounded-2xl bg-white border border-slate-200 p-5">
      <div className="flex items-center justify-between mb-1">
        <h3 className="text-sm font-bold text-slate-900">Max price</h3>
        <span className="text-sm font-semibold text-slate-700">
          {maxPrice === 0 ? 'Free only' : `Up to $${maxPrice}`}
        </span>
      </div>
      <p className="text-xs text-slate-400 mb-4">
        {stats.max === 0
          ? 'All these events are free.'
          : `Events range from ${stats.min === 0 ? 'free' : `$${stats.min}`} to $${stats.max}.`}
      </p>

      <input
        type="range"
        min={0}
        max={sliderMax}
        step={5}
        value={maxPrice}
        onChange={(e) => onMaxPriceChange(Number(e.target.value))}
        className="w-full h-2 rounded-full appearance-none cursor-pointer accent-slate-900
          [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5
          [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-slate-900
          [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer
          [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:rounded-full
          [&::-moz-range-thumb]:bg-slate-900 [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:cursor-pointer"
      />

      <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
        <span>Free</span>
        <span className="font-medium text-slate-600">
          Showing {within} of {events.length}
        </span>
        <span>${sliderMax}+</span>
      </div>
    </div>
  );
}
