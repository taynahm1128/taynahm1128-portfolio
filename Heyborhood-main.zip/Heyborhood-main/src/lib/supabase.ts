import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type AgeGroup = 'kids' | 'teens' | 'adults';

export interface Event {
  id: string;
  title: string;
  description: string | null;
  age_group: AgeGroup;
  date: string;
  time: string | null;
  location: string;
  image_url: string | null;
  category: string | null;
  price: string | null;
  created_at: string;
  created_by: string | null;
}

export interface Profile {
  id: string;
  name: string;
  age: number | null;
  is_guest: boolean;
  avatar_url: string | null;
  preferred_activities: string[] | null;
  created_at: string;
  updated_at: string;
}
