export interface Activity {
  id: string;
  label: string;
  emoji: string;
}

export const ACTIVITIES: Activity[] = [
  { id: 'sports', label: 'Sports', emoji: '⚽' },
  { id: 'music', label: 'Music', emoji: '🎵' },
  { id: 'arts-crafts', label: 'Arts & Crafts', emoji: '🎨' },
  { id: 'outdoor', label: 'Outdoor', emoji: '🌳' },
  { id: 'food', label: 'Food & Drink', emoji: '🍽️' },
  { id: 'gaming', label: 'Gaming', emoji: '🎮' },
  { id: 'tech', label: 'Tech', emoji: '💻' },
  { id: 'reading', label: 'Reading', emoji: '📚' },
  { id: 'dance', label: 'Dance', emoji: '💃' },
  { id: 'fitness', label: 'Fitness', emoji: '🏃' },
  { id: 'nature', label: 'Nature', emoji: '🌿' },
  { id: 'volunteering', label: 'Volunteering', emoji: '🤝' },
  { id: 'movies', label: 'Movies', emoji: '🎬' },
  { id: 'shopping', label: 'Shopping', emoji: '🛍️' },
  { id: 'family', label: 'Family', emoji: '👨‍👩‍👧' },
  { id: 'education', label: 'Education', emoji: '🎓' },
];

export function getActivityLabel(id: string): string {
  return ACTIVITIES.find((a) => a.id === id)?.label ?? id;
}
