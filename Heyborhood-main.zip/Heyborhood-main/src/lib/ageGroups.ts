import type { AgeGroup } from './supabase';

export interface AgeGroupInfo {
  id: AgeGroup;
  label: string;
  range: string;
  description: string;
  gradient: string;
  accent: string;
  ring: string;
  text: string;
  bg: string;
  border: string;
  emoji: string;
}

export const AGE_GROUPS: AgeGroupInfo[] = [
  {
    id: 'kids',
    label: 'Kids',
    range: 'Ages 3–12',
    description: 'Play, learn, and explore with family-friendly events designed for little ones.',
    gradient: 'from-amber-400 via-orange-400 to-rose-400',
    accent: 'amber',
    ring: 'ring-amber-400',
    text: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    emoji: '🎈',
  },
  {
    id: 'teens',
    label: 'Teens',
    range: 'Ages 13–17',
    description: 'Music, sports, and social events where teens can hang out and have fun.',
    gradient: 'from-emerald-400 via-teal-400 to-cyan-500',
    accent: 'emerald',
    ring: 'ring-emerald-400',
    text: 'text-emerald-600',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    emoji: '🎧',
  },
  {
    id: 'adults',
    label: 'Adults',
    range: 'Ages 18+',
    description: 'Unwind and connect with nightlife, sports, and social events in the neighborhood.',
    gradient: 'from-sky-500 via-blue-600 to-indigo-700',
    accent: 'blue',
    ring: 'ring-blue-500',
    text: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    emoji: '🍸',
  },
];

export function getAgeGroupInfo(id: AgeGroup): AgeGroupInfo {
  return AGE_GROUPS.find((g) => g.id === id) ?? AGE_GROUPS[0];
}

export function formatDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

export function formatLongDate(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}
