/*
# Create profiles table for Heyborhood sign-up

## Purpose
Stores user profile information collected during the sign-up / onboarding flow.
Each profile records the person's name, age, and whether they chose to sign up
as a guest. Guest profiles are created without any account credentials so the
user can browse events immediately.

## New Tables
### profiles
- `id` (uuid, primary key) — unique identifier for the profile
- `name` (text, not null) — display name the user enters (e.g. "Amarieh")
- `age` (integer) — the user's age, optional for guests
- `is_guest` (boolean, not null, default false) — true when the user chose the guest option
- `created_at` (timestamptz) — when the profile was created
- `updated_at` (timestamptz) — when the profile was last updated

## Security
- RLS enabled on profiles table
- Public read/write via anon + authenticated — this is a lightweight
  community app where profiles are intentionally shared/public so that any
  visitor can onboard without a login wall. No sensitive data (no email,
  password, or contact info) is stored in this table.

## Notes
- No foreign key to auth.users because this table is intentionally used by
  both guests and (future) authenticated users. The id is an independent UUID.
- Age is nullable so guests who skip entering personal details can still be saved.
- No unique constraints on name — multiple community members may share a name.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  age integer,
  is_guest boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_profiles" ON profiles;
CREATE POLICY "anon_select_profiles" ON profiles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_profiles" ON profiles;
CREATE POLICY "anon_insert_profiles" ON profiles FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_profiles" ON profiles;
CREATE POLICY "anon_update_profiles" ON profiles FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_profiles" ON profiles;
CREATE POLICY "anon_delete_profiles" ON profiles FOR DELETE
  TO anon, authenticated USING (true);
